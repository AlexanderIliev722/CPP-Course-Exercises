#ifndef POINT_H_INCLUDED
#define POINT_H_INCLUDED

class Point{
public:
Point(int , int);
void setX(int);
int getX();
void setY(int);
int getY();

private:
int x;
int y;
};

#endif // POINT_H_INCLUDED
