#ifndef COMPANY_H_INCLUDED
#define COMPANY_H_INCLUDED
#include <iostream>
 using namespace std;
  class Company{
  public:

  private:


  };

#endif // COMPANY_H_INCLUDED
