#ifndef CARS_H_INCLUDED
#define CARS_H_INCLUDED
#include <iostream>

using namespace std;

class Cars{
public:


private:
string brand;
string model;
string type;
string vin;
string numberOfCar;
double gasRazhod;
int feeOfUse;

};

#endif // CARS_H_INCLUDED
