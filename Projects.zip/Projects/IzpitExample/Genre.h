#ifndef GENRE_H_INCLUDED
#define GENRE_H_INCLUDED

class Genre{
public:
Genre(int);
void setGenre(int);
int getGenre();
void print();

private:
int genre;
};

#endif // GENRE_H_INCLUDED
